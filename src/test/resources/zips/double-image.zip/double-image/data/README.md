A sample dataset
================

This dataset is not too big, but big enough to demonstrate some features of the
SWORD v2.0 service and the EASY Ingest Flow.

- A display name is provided for data/random images/image01.png
- An additional license is selected

